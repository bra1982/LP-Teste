
			<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
			<html xmlns="http://www.w3.org/1999/xhtml" class="gray">
			  <head>
				<title>Not Found</title>
				<link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
				<link rel="stylesheet" type="text/css" href="https://cdn.awsli.com.br/production/static/css/varnish.css">
			  </head>
			  <body>
				<div class="u-valign-wrapper">
				  <div class="u-valign">
					<div class="text">
					  <h1>Ops :(</h1>
					  <p class="descr">Not Found</p>
					</div>
				  </div>
				</div>
			  </body>
			</html>
        